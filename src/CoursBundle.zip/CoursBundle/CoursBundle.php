<?php

namespace CoursBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class CoursBundle extends Bundle
{
}
