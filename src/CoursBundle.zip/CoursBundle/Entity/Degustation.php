<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace CoursBundle\Entity;

/**
 * Description of Degustation
 *
 * @author dumollard
 */
class Degustation {
   
    /**
     *
     * @var integer identifiant de la fiche de degustation
     */
    private $degustationId;
    
    /**
     *
     * @var integer $identifiant du vin
     */
    private $vinId;
    
    /**
     *
     * @var integer identifiant de l'utilisateur
     */
    private $userId;
    
   /**
    *
    * @var string description du vin v visuel o olfactif g gout 
    */
    private $vLimpidite;
       /**
    *
    * @var string description du vin v visuel o olfactif g gout 
    */
    private $vIntensite;
       /**
    *
    * @var string description du vin v visuel o olfactif g gout 
    */
    private $vNuance;
       /**
    *
    * @var string description du vin v visuel o olfactif g gout 
    */
    private $vGlycerol;
       /**
    *
    * @var string description du vin v visuel o olfactif g gout 
    */
    private $oIntensite;
       /**
    *
    * @var string description du vin v visuel o olfactif g gout 
    */
    private $oImpression;
       /**
    *
    * @var string description du vin v visuel o olfactif g gout 
    */
    private $oNunces;
       /**
    *
    * @var string description du vin v visuel o olfactif g gout 
    */
    private $oPersistance;
       /**
    *
    * @var string description du vin v visuel o olfactif g gout 
    */
    private $gAttaque;
       /**
    *
    * @var string description du vin v visuel o olfactif g gout 
    */
    private $gSaveur;
       /**
    *
    * @var string description du vin v visuel o olfactif g gout 
    */
    private $gEquilibre;
       /**
    *
    * @var string description du vin v visuel o olfactif g gout 
    */
    private $gTanin;
       /**
    *
    * @var string description du vin v visuel o olfactif g gout 
    */
    private $gRetro;
       /**
    *
    * @var string deolution du vin 
    */
    private $cEvolution;
       /**
    *
    * @var string avenir possible
    */
    private $cAvenir;
    
    
           
}
