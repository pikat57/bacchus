<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace CoursBundle\Entity;

/**
 * Description of Utilisateur
 *
 * @author dumollard
 */
class Utilisateur {
    //put your code here
    
    private $utilisateurId;
    private $nom;
    private $prenom;
    private $anneeNaissance;
    private $sexe;
    private $password;
}
