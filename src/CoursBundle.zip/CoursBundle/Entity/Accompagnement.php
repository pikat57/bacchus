<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace CoursBundle\Entity;

/**
 * Description of Accompagnement
 *
 * @author dumollard
 */
class Accompagnement {
    
    
/**
 *
 * @var integer identifiant unique de l'accompagnement
 */    
private $accompagnementId;

/**
 *
 * @var Integer identifiant du vin
 */
private $vinId;

/**
 *
 * @var Identifiant du plat 
 */
private $platId;



    //put your code here
}
