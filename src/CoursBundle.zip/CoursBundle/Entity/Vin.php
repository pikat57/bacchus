<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace CoursBundle\Entity;

/**
 * Description of Vin
 *
 * @author dumollard
 */
class Vin {
    
    
    /**
     *
     * @var integer identifiant unique du vin
     */
    private $vinId;
    
    /**
     *
     * @var string nom du vin
     */
    private $nom;
    
    /**
     *
     * @var integer identifiant du cepage
     */
    private $cepageId;
    
    /**
     *
     * @var integer année de production
     */
    private $millesime;
    
    /**
     *
     * @var integer identifiant du terroir
     */
    private $terroirId;
    
    /**
     *
     * @var integer identifiant du producteur
     */
    private $producteurId;
    
    /**
     *
     * @var integer identifiant de l'accompagnement
     */
    private $accompagnementId;
    
    /**
     *
     * @var integer nombre d'année de conservation
     */
    private $nbAnneeConservation;
    
    /**
     *
     * @var string type de vendange normale tardive ....
     */
    private $typeVendange;
    
    /**
     *
     * @var string type de vin ou methode de vinification... 
     */
    private $type;
    
    /**
     *
     * @var integer prix moyen constatée
     *
     *
     */
    private $prixMoyen;
    
    
    
    
}
