<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace CoursBundle\Entity;

/**
 * Description of Producteur
 *
 * @author dumollard
 */
class Producteur {
    
    
    /**
     *
     * @var integer identifiant unique du producteur
     */
    private $producteurId;
    
    /**
     *
     * @var string nom du producteur
     */
    private $nom;
    
    /**
     *
     * @var integer adresse du producteur
     *     
     */
    
    private $adresse;
    
    /**
     *
     * @var string ville de production
     */
    private $ville;
    
    
    /**
     *
     * @var string pays de production
     */
    private $pays;
    
    /**
     *
     * @var string nom du responsable
     */
    private $responsable;
    
    
    /**
     *
     * @var integer téléphone du producteur
     */
    private $telephone;
    
    /**
     *
     * @var string adresse mail du producteur 
     */
    private $mail;
    
    
    /**
     *
     * @var string site web  du producteur
     */
    private $siteWeb;
    
    


    //put your code here
}
