<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace CoursBundle\Entity;

/**
 * Description of Terroir
 *
 * @author dumollard
 */
class Terroir {
    //put your code here
    
    private $terroirId;
    private $nom;
    private $region;
    private $sol;
    private $climat;
    private $pays;
    private $ville;
    
           
}
