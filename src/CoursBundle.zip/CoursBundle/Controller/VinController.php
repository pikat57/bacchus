<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

namespace CoursBundle\Controller;



use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use \MonDoctrineBundle\Entity\Vin;



/**
 * Description of VinController
 *
 * @author jean-yves
 */
class VinController extends Controller {
    
    public function manageAction(){
        
        $manager = $this->getDoctrine()->getManager();
       
        
        /*$article = new Article;
        $article->setNom("PHP pour les nuls");
        $article->setDescription("S Zins met le php à la portée de tous");
        $article->setStock(0);
        
        
        $manager->persist($article);
        
        $manager->flush();*/
        
        
    }
    
    
}
